//
//  main.cpp
//  problem2p6
//
//  Created by Dendi Suhubdy on 8/25/14.
//  Copyright (c) 2014 NCSU. All rights reserved.
//

#include <iostream>

#include "temp.h"

int main(int argc, const char * argv[])
{
    temp temperature;
    temperature.getinput();
    temperature.displayoutput();
    return 0;
}
