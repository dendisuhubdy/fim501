//
//  main.cpp
//  exercise3p4
//
//  Created by Dendi Suhubdy on 9/10/14.
//  Copyright (c) 2014 NCSU. All rights reserved.
//

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

double FV(double PV, double r, int n);

int main(int argc, const char * argv[])
{
    double rate;
    for(int pv = 1000; pv <=10000; pv+=1000)
    {
        for(int n =1; n <=10; n++)
        {
            cout << n << " year ";
            for (double i = 10; i<=20; i++) // to avoid noncompliant code, a floating-point variable is used as a loop counter.
            {
                rate = i/100;
                cout << FV(pv, rate,n) << "\t";
            }
            cout << endl;
        }
        cout << endl;
    }
    return 0;
}

double FV(double PV, double r, int n)
{
    return (PV * pow((1+r),n));
}
