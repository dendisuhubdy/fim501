//
//  main.cpp
//  exercise3p7
//
//  Created by Dendi Suhubdy on 9/10/14.
//  Copyright (c) 2014 NCSU. All rights reserved.
//

#include <iostream>
#include <cmath>
#include <ctime>


using namespace std;

#define RAD 0.0174532925

/*
// the use of unsigned long long factorial(int number)
// is to get rid of the limits of memory under long number limits
// so the boundary does not become a random number
 */

unsigned long long factorial(int number);
double sin_taylor(double x, int maxN,double tolerance);
double cos_taylor(double x, int maxN,double tolerance);
double sum_taylor(int maxN, double tolerance);

int main(int argc, const char * argv[])
{
    clock_t begin, end;
    double time_spent;
    begin = clock();
    
    double x, radians, tolerance;
    double sumterms, sumtolerance;
    int terms;
    
    cout << "Taylor series approximation of sin x, cos x" << endl;
    cout << "Input x in degrees : ";
    cin  >> x;
    radians = x * RAD;
    cout << "Input maximum number of terms to evaluate: ";
    cin  >> terms;
    cout << "Input the tolerance: ";
    cin  >> tolerance;
    
    cout << "sin(" << x << ") = " << sin_taylor(radians, terms, tolerance) << endl;
    cout << "The last term of the sin taylor approx is = " << fabs(sin_taylor(radians, terms, tolerance) - sin_taylor(radians, terms-1, tolerance)) << endl;
    cout << "cos(" << x << ") = " << cos_taylor(radians, terms, tolerance) << endl;
    cout << "The last term of the cos taylor approx is = " << fabs(cos_taylor(radians, terms, tolerance)-cos_taylor(radians, terms-1, tolerance)) << endl;
    
    cout << endl;
    cout << "Taylor series approximation of Taylor SUM" << endl;
    cout << "Input the terms to evaluate on the Taylor SUM: ";
    cin  >> sumterms;
    cout << "Input the tolerance rate on the Taylor SUM: ";
    cin  >> sumtolerance;
    cout << "The Taylor SUM of " << sumterms << " terms are = " << sum_taylor(sumterms, sumtolerance) << endl;
    cout << "The last term of the SUM is = " << fabs(sum_taylor(sumterms, sumtolerance) - sum_taylor(sumterms - 1, sumtolerance)) << endl;
    
    end = clock();
    time_spent = (double)(end - begin)*1000 / CLOCKS_PER_SEC;
    
    cout << endl
         << "Execution time: "
         << time_spent
         << " miliseconds"
         << endl;
    
    return 0;
}

unsigned long long factorial(int number)
{
    if (number==0)
    {
        return 1;
    }
    else
    {
        return (number * factorial(number-1));
    }
}

double sin_taylor(double x, int maxN, double tolerance)
{
    if(maxN==1)
    {
        return x;
    }
    
    double result = 0;
    for (int j =1; j<=maxN;j++)
    {
        if(j%2 == 1) //for differentiating subtracting or adding series
        {
            result += pow(x, j*2-1) / factorial(j*2-1);
            if (fabs((pow(x, j*2-1) / factorial(j*2-1))/result)<=tolerance)
            {
                break;
            }
        }
        else
        {
            result -= pow(x, j*2-1)/ factorial(j*2-1);
            if (fabs((pow(x, j*2-1) / factorial(j*2-1))/result)<=tolerance)
            {
                break;
            }
        }
    }
    return (result);
}

double cos_taylor(double x, int maxN, double tolerance)
{
    if(maxN==1)
    {
        return 1;
    }
    
    double result = 0;
    for (int j =1; j<=maxN;j++)
    {
        if(j%2 == 1) //for differentiating subtracting or adding series
        {
            result += pow(x, j*2-2) / factorial(j*2-2);
            if (fabs((pow(x, j*2-2) / factorial(j*2-2))/result)<=tolerance)
            {
                break;
            }
        }
        else
        {
            result -= pow(x, j*2-2)/ factorial(j*2-2);
            if (fabs((pow(x, j*2-2) / factorial(j*2-2))/result)<=tolerance)
            {
                break;
            }
        }
    }
    return (result);
}

double sum_taylor(int maxN, double tolerance)
{
    double result=1;
    for (int j =1; j<=maxN;j++)
    {
        result += pow((1/j),j);
        if (fabs(pow((1/j),j)/result)<=tolerance)
        {
            break;
        }
    }
    
    return (result);
}

