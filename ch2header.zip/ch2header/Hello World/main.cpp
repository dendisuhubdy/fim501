//
//  main.cpp
//  Hello World
//
//  Created by Dendi Suhubdy on 8/20/14.
//  Copyright (c) 2014 NCSU. All rights reserved.
//

#include <iostream> //header file

#include "people.h"

int main(void)
{
    people p;
    p.getdata();
    p.display();
    return 0;
}

