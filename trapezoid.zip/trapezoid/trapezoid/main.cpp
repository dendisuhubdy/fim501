//
//  main.cpp
//  trapezoid
//
//  Created by Dendi Suhubdy on 9/10/14.
//  Copyright (c) 2014 NCSU. All rights reserved.
//

#include<iostream>  //Header file for cin & cout
#include<cmath>  //Header file for mathematical operartions
using namespace std;  //calling the standard directory

//Taking a function f(x)
double func(double x);
double trapezoidalrule(double nSegs, double a, double b);

int main(void)  //Main Program
{
    double a, b, n;
    cout <<" Given f(x)= e^(-x^2) "<<endl;
    cout << "Enter lower limit of the integral: ";
    cin  >> a;
    cout << "Enter Upper limit of the integral:  ";
    cin  >> b;
    cout << "Enter the number of intervals(segments) : ";
    cin  >> n;
    
    //Printing the value of Integral
    cout << "The Value of integral under the enterd limits is : " << trapezoidalrule(n, a, b)<< endl;
    return 0;
}

double func(double x)
{
    return (exp(-(pow(x,2))));
}

double trapezoidalrule(double nSegs, double a, double b)
{
    double h, results;
    double I=0.0;
    double J =0.0;
    int i = 0;
    h=(b-a)/nSegs;
    
    //Steps of solving by Trapezoidal Rule
    for(int i=0;i<=nSegs;i++)
    {
        I = I + func( a + (i * h));
    }
    
    for(i=1;i<nSegs;i++)
    {
        J = J + func( a + (i * h));
    }
    
    results = ( h / 2 ) * ( I + J);
    
    return (results);
}
